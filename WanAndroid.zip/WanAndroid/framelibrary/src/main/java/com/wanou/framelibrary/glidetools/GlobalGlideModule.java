package com.wanou.framelibrary.glidetools;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Author by wodx521
 * Date on 2018/11/8.
 */

@GlideModule
public class GlobalGlideModule extends AppGlideModule {
}
