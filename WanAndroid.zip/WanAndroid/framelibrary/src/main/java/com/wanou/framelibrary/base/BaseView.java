package com.wanou.framelibrary.base;

/**
 * Author by wodx521
 * Date on 2018/11/10.
 */
public interface BaseView {


}
