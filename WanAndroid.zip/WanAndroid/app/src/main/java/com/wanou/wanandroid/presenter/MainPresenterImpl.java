package com.wanou.wanandroid.presenter;

import com.wanou.framelibrary.base.BasePresenterImpl;
import com.wanou.wanandroid.view.activity.MainActivity;

/**
 * Author by wodx521
 * Date on 2018/11/16.
 */
public class MainPresenterImpl extends BasePresenterImpl<MainActivity> {


}
