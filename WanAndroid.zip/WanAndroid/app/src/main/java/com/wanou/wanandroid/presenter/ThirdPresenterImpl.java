package com.wanou.wanandroid.presenter;

import com.wanou.framelibrary.base.BasePresenterImpl;
import com.wanou.wanandroid.view.fragment.ThirdMainFragment;

/**
 * Author by wodx521
 * Date on 2018/11/13.
 */
public class ThirdPresenterImpl extends BasePresenterImpl<ThirdMainFragment> {


}
