package com.wanou.wanandroid.constant;

/**
 * Author by wodx521
 * Date on 2018/11/16.
 */
public class UrlConstant {
    public static final String BASEURL = "http://www.wanandroid.com";
}
